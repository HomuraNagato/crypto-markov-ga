#!/usr/bin/env python
import sys
import csv

furniture_path = ''

def main():
    '''
    For CSV:
    with open(furniture_path) as f:
        reader = csv.reader(f)
    '''
    # TODO: clean furniture.csv
    pass

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print 'Usage: python clean_furniture.py furniture'
    furniture_path = sys.argv[1]
    main()
